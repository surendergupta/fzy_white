import React from 'react'

const Register = () => {
  return (
    <div className='register'>Register</div>
  )
}

export default Register;