import React from 'react';
import './navbar.scss';
import { NavLink } from 'react-router-dom';
import logo from '../../assets/images/logo.png'
const Navbar = () => {
  return (
    <div className='navbar'>
        <div className='navbarContainer'>
            <div className='logo'>
                <img src={logo} alt='Fizzyfy Coin' />
            </div>
            <div className='navlist'>
                <ul>
                    <li>
                        <NavLink className='navlink' to={'/'}>Feature</NavLink>
                    </li>
                    <li>
                        <NavLink className='navlink' to={'/'}>Product</NavLink>
                    </li>
                    <li>
                        <NavLink className='navlink' to={'/'}>Roadmap</NavLink>
                    </li>
                    <li>
                        <NavLink className='navlink' to={'/'}>About</NavLink>
                    </li>
                    <li>
                        <NavLink className='navlink' to={'/'}>Tokens</NavLink>
                    </li>
                    <li>
                        <NavLink className='navlink' to={'/register'}>Register</NavLink>
                    </li>
                    <li>
                        <NavLink className='navlink' to={'/login'}>Login</NavLink>
                    </li>
                </ul>
            </div>
        </div>
    </div>
  )
}

export default Navbar;