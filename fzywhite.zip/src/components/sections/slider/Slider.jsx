import React from 'react';
import './slider.scss';
import { Grid } from '@mui/material';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';

import client1 from '../../../assets/images/clients-slider/1.png';
import client2 from '../../../assets/images/clients-slider/2.png';
import client3 from '../../../assets/images/clients-slider/3.png';
import client4 from '../../../assets/images/clients-slider/4.png';
import client5 from '../../../assets/images/clients-slider/5.png';

const Slider = () => {
    const responsive = {
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 3,
            slidesToSlide: 3 // optional, default to 1.
          },
          tablet: {
            breakpoint: { max: 1024, min: 464 },
            items: 2,
            slidesToSlide: 2 // optional, default to 1.
          },
          mobile: {
            breakpoint: { max: 464, min: 0 },
            items: 1,
            slidesToSlide: 1 // optional, default to 1.
          }
      };
  return (
    <div className='slider'>
        <div className='sliderContainer'>
            <div className='brandslider'>
                <Grid
                container
                direction="row"
                justifyContent="space-evenly"
                alignItems="center"
                >
                    <Carousel 
                    responsive={responsive}
                    autoPlaySpeed={1000}
                    swipeable={false}
                    draggable={false}
                    showDots={true}
                    infinite={true}
                    keyBoardControl={true}
                    arrows={false}                     
                    customTransition="all .5"
                    transitionDuration={500}
                    containerClass="carousel-container"
                    removeArrowOnDeviceType={["tablet", "mobile"]}
                    dotListClass="custom-dot-list-style"
                    itemClass="carousel-item-padding-40-px"
                    >
                        <div><img src={client1} alt='client 1' /></div>
                        <div><img src={client2} alt='client 2' /></div>
                        <div><img src={client3} alt='client 3' /></div>
                        <div><img src={client4} alt='client 4' /></div>
                        <div><img src={client5} alt='client 5' /></div>
                    </Carousel>
                </Grid>
            </div>
        </div>
    </div>
  )
}

export default Slider;