import React from 'react';
import './subscription.scss';

const Subscription = () => {
  return (
    <div className='subscription'>
        <div className='subscriptionContainer'>
            Subscription
        </div>
    </div>
  )
}

export default Subscription;